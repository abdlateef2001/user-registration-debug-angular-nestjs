# Angular Client
This is the placeholder for the Angular frontend.